<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ticket_status extends Model
{
    protected $table = 'ticket_status';
}
