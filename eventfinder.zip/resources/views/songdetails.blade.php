@extends('layout.layout')

@section('content')
    {{$song->name}}
@endsection