@extends('layout.layout');

@section('content');
<h1>Test</h1>
@endsection;