

<?php $__env->startSection('content'); ?>
    <?php echo e($song->name); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Matty\Desktop\eventfinder\resources\views/songdetails.blade.php ENDPATH**/ ?>