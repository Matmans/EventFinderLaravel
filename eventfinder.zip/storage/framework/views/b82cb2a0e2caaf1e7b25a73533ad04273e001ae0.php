;

<?php $__env->startSection('content'); ?>;
    <div class="text-center">
        <!-- Artiest info -->
        <?php $__currentLoopData = $artist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artiest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($artiest->name); ?>

            <?php echo e($artiest->formation); ?>

            <?php echo e($artiest->genre['name']); ?>

            <?php echo e($artiest->country['name']); ?>

            <!-- Links -->
            <?php echo e($artiest->facebooklink); ?>

            <?php echo e($artiest->twitterlink); ?>

            <?php echo e($artiest->youtubelink); ?>

            <!-- Link naar artiest pagina -->
            <a href='/artist/<?php echo e($artiest->id); ?>'>Meer info over artiest</a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <br/>
        <!-- Concerten -->
        <?php $__currentLoopData = $concert; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($c->location); ?>

            <?php echo e($c->date); ?>

            <?php echo e($c->country['name']); ?>


            <?php if($c->meetandgreet = 1): ?>
                <p>Er is een meet and greet</p>
            <?php endif; ?>
        
            <?php if($c->merchandise = 1): ?>
            <p>MERCH!</p>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <!-- Ticket info voor bij de concerten -->
        <?php $__currentLoopData = $ticket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($t->status_id = 1): ?>
                <button class="btn btn-secondary btn p-2 disabled"disabled>
                    NOG NIET BESCHIKBAAR
                </button>
            <?php elseif($t->status_id = 2): ?>
                <button class="btn btn-success btn-sm " href="<?php echo e($t->link); ?>">
                    GET YOUR <br> TICKETS HERE
                </button>
            <?php elseif($t->status_id = 3): ?>
                <button class="btn btn-secondary btn p-2 disabled"disabled>
                    UITVERKOCHT
                </button>
            <?php elseif($t->status_id = 4): ?>
                <button class="btn btn-secondary btn p-2 disabled"disabled>
                    CONCERT GEANNULEERD
                </button>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>;
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Matty\Desktop\eventfinder\resources\views//concert.blade.php ENDPATH**/ ?>