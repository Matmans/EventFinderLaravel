<?php $__env->startSection('content'); ?>
    <div class="text-center">
        <h1 class="display-4" id="titel">SEARCH FOR UPCOMING EVENTS!</h1>

        <form action="/searchconcert" method="POST" role="search">
            <?php echo e(csrf_field()); ?>

            <div class="input-group active-cyan-3 active-cyan-4">
                <input type="text" class="form-control" name="zoek" placeholder="Search here for an artist"> <br/>

                <select name="zoekcountry" id="zoekcountry">
                    <option value="0">Filter by country</option>
                    <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <span class="input-group-btn">
                    <button type="submit" class="btn btn-warning mr-5 btn-lg pl-5 pr-5">
                    Search
                    </button>
                </span>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Matty\Desktop\eventfinder\resources\views//welcome.blade.php ENDPATH**/ ?>