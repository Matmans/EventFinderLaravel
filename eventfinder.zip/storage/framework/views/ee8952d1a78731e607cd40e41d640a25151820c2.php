

<?php $__env->startSection('content'); ?>
    <?php echo e($country['name']); ?>

    
    <?php $__currentLoopData = $concert; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($con->location); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Matty\Desktop\eventfinder\resources\views/countrydetails.blade.php ENDPATH**/ ?>