

<?php $__env->startSection('content'); ?>
    <?php echo e($artist->name); ?>

    <?php echo e($artist->country['name']); ?>

    <img src="<?php echo e($artist->piclink); ?>" />

    <?php $__currentLoopData = $song; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="/song/<?php echo e($s->id); ?>"><?php echo e($s['name']); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Matty\Desktop\eventfinder\resources\views/artiestdetails.blade.php ENDPATH**/ ?>